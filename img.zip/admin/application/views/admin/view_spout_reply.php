<?php
echo "test";
exit;